# 🔍 ReconX — Domain & IP OSINT Reconnaissance Tool

<p align="center">
  <img src="https://img.shields.io/badge/python-3.10%2B-blue?style=flat-square&logo=python" />
  <img src="https://img.shields.io/badge/platform-Linux%20%7C%20Kali-green?style=flat-square" />
  <img src="https://img.shields.io/badge/license-MIT-orange?style=flat-square" />
  <img src="https://img.shields.io/badge/OSINT-tool-red?style=flat-square" />
</p>

> A modular, CLI-based OSINT reconnaissance tool for domains and IP addresses.  
> Built for security researchers, CTF players and penetration testers.

---

## Features

| Module | Description |
|--------|-------------|
| 🔎 **WHOIS** | Registrar, registrant, dates, name servers, DNSSEC |
| 🌐 **DNS Enum** | A, AAAA, MX, NS, TXT, CNAME, SOA, CAA, PTR records |
| 🔗 **Subdomain Scan** | Brute-force via customizable wordlist, multi-threaded |
| 🚪 **Port Scan** | Top 100 ports, banner grabbing, service detection |
| 💾 **JSON Output** | Save full results to structured JSON file |

---

## Installation

```bash
# Clone the repo
git clone https://github.com/yourusername/reconx.git
cd reconx

# Make executable
chmod +x reconx.py

# No pip install needed — uses Python standard library only
# Optional: install whois and dnsutils for best results
sudo apt install whois dnsutils
```

---

## Usage

```bash
# Run all modules
python3 reconx.py example.com

# Run specific modules
python3 reconx.py example.com -w -d          # WHOIS + DNS
python3 reconx.py example.com -s             # Subdomains only
python3 reconx.py example.com -p             # Ports only

# Save output to JSON
python3 reconx.py example.com -a -o results/example.json

# Custom wordlist + more ports
python3 reconx.py example.com -s --wordlist /usr/share/wordlists/subdomains.txt
python3 reconx.py example.com -p --top-ports 200 --timeout 0.5
```

### All flags

```
positional:
  target              Target domain or IP (e.g. example.com)

optional:
  -w, --whois         WHOIS lookup
  -d, --dns           DNS enumeration
  -s, --subdomains    Subdomain brute-force
  -p, --ports         Port scan
  -a, --all           Run all modules (default if no flag given)
  -o FILE             Save results to JSON file
  --wordlist FILE     Custom subdomain wordlist
  --top-ports N       Number of ports to scan (default: 100)
  --timeout SECS      Connection timeout (default: 1.0)
```

---

## Example Output

```
 ██████╗ ███████╗ ██████╗ ██████╗ ███╗   ██╗██╗  ██╗
 ██╔══██╗██╔════╝██╔════╝██╔═══██╗████╗  ██║╚██╗██╔╝
 ...

[*] Target  : example.com
[*] Started : 2024-11-15 14:32:01
[*] Modules : ALL

────────────────────────────────────────────────────────────
  ◈  WHOIS LOOKUP
────────────────────────────────────────────────────────────
    Domain Name          example.com
    Registrar            IANA
    Created              1995-08-14T04:00:00Z
    Expires              2025-08-13T04:00:00Z
    Name Servers         a.iana-servers.net
    DNSSEC               signedDelegation

────────────────────────────────────────────────────────────
  ◈  DNS ENUMERATION
────────────────────────────────────────────────────────────
    A                    93.184.216.34
    AAAA                 2606:2800:21f:cb07:6820:80da:af6b:8b2c
    MX                   .
    NS                   a.iana-servers.net.
    TXT                  "v=spf1 -all"

────────────────────────────────────────────────────────────
  ◈  PORT SCAN
────────────────────────────────────────────────────────────
    PORT     STATE    SERVICE          BANNER
    ─────── ─────── ─────────────── ────────────────────
    OPEN   80      HTTP             
    OPEN   443     HTTPS            

[+] Found 2 open port(s).
```

---

## Project Structure

```
reconx/
├── reconx.py               # Main entry point
├── modules/
│   ├── banner.py           # ASCII banner
│   ├── whois_lookup.py     # WHOIS module
│   ├── dns_enum.py         # DNS enumeration
│   ├── subdomain_scan.py   # Subdomain brute-force
│   ├── port_scan.py        # Port scanner + banner grabbing
│   └── utils.py            # Colors, print helpers
├── wordlists/
│   └── subdomains.txt      # Default subdomain wordlist
├── requirements.txt
└── README.md
```

---

## Compatibility

- ✅ Kali Linux (recommended)
- ✅ Ubuntu / Debian
- ✅ macOS (without `dig`/`whois` fallback to socket)
- ✅ Python 3.10+
- ❌ Windows (not tested)

---

## Disclaimer

> This tool is intended for **educational purposes** and **authorized penetration testing only**.  
> Always obtain proper written permission before scanning systems you do not own.  
> The author is not responsible for any misuse or damage caused by this tool.

---

## License

MIT License — see [LICENSE](LICENSE) for details.
